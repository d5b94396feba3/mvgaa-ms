<?php 

	// DB Config
	$servername = "localhost";
	$username = "u563871600_mvga_admin";
	$password = "yj4wPhKi98UcU2S@";
	$dbname = "u563871600_db_mvga";

	// Create connection
	$conn = new mysqli($servername, $username, $password, $dbname);
	// Check connection
	if ($conn->connect_error) {
	  die("Connection failed: " . $conn->connect_error);
	}
?>